<?php
require_once './shared/header.php';
require_once './shared/guard.php';
?>
<section class="section">
    <div class="container">
      <h1 class="title">
        Page 5
      </h1>
      <p class="subtitle">
        Page 5 content
      </p>
    </div>
</section>
<?php require_once './shared/footer.php' ?>