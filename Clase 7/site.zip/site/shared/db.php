<?php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Animal.php';

use crojasaragonez\UtnDb\PgConnection;

$con = new PgConnection('postgres', '12345', 'isw', 5432, 'localhost');
$con->connect();

$user_model = new User($con);
$animal_model = new Animal($con);

/*
$sql = "INSERT INTO users(email, password) VALUES ($1, md5($2))";
$con->runStatement($sql, ['estudiante@est.utn.ac.cr', '12345']);

$results = $con->runQuery('SELECT * FROM users WHERE id >= $1', [1]);

var_dump($results);

$con->disconnect();
*/